from headers.fake import create_faker


class Header:
    def __init__(self):
        self.header = create_faker()
